# CVAT_Video_Annotation_Processor
CVAT_Video_Annotation_Processor: Open-source Python package for processing video data with CVAT annotations. Extract, manipulate, and analyze video ROIs effortlessly.
